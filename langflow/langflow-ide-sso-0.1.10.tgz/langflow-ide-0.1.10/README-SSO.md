# Langflow on PCAI — Keycloak SSO as a runtime pluggable service (no custom image)

This chart runs the **stock** `langflowai/langflow:1.10.0` backend image and adds
Keycloak SSO at runtime via Langflow's pluggable `auth_service` layer. There is
**no Docker build** and **no PyPI/airgap dependency** — the plugin ships as chart
files, mounted into the pod from ConfigMaps.

---

## 1. Where everything lives

### In the chart (what you edit / ship)

```
langflow-ide-0.1.10/
├─ files/sso/
│  ├─ lfx.toml                      # registers auth_service -> KeycloakAuthService
│  └─ pcai_keycloak/                # the plugin Python package
│     ├─ __init__.py
│     └─ auth.py                    # <-- THE KEYCLOAK AUTH SERVICE (edit here)
├─ templates/
│  ├─ sso-plugin-configmap.yaml     # NEW: inlines files/sso/* into 2 ConfigMaps
│  └─ backend-statefulset.yaml      # CHANGED: command now runs stock langflow
└─ values.yaml                      # CHANGED: stock image + SSO env + mounts
```

You only ever edit `files/sso/pcai_keycloak/auth.py`. Do **not** edit anything
inside the running pod — it is a read-only ConfigMap mount.

### In the running pod (what gets mounted, automatically)

| Source (chart)                         | ConfigMap                       | Pod path                                   |
| -------------------------------------- | ------------------------------- | ------------------------------------------ |
| `files/sso/pcai_keycloak/*.py`         | `langflow-service-sso-plugin`   | `/opt/langflow-sso/pcai_keycloak/`         |
| `files/sso/lfx.toml`                   | `langflow-service-lfx-config`   | `/app/data/lfx.toml`                       |

Discovery chain at startup:
`PYTHONPATH=/opt/langflow-sso` → `import pcai_keycloak.auth` →
`LANGFLOW_CONFIG_DIR=/app/data` → `lfx.toml` registers
`auth_service = "pcai_keycloak.auth:KeycloakAuthService"` → it overrides the
built-in JWT auth service.

> ConfigMap names assume `fullnameOverride: langflow-service` (the chart default),
> which yields `langflow-service-sso-plugin` and `langflow-service-lfx-config`.
> If you change `fullnameOverride`, update the two `configMap.name` references in
> `values.yaml` under `langflow.backend.volumes`.

---

## 2. How the request flow works (PCAI topology)

```
Browser ──▶ Istio ezaf-gateway ──▶ oauth2-proxy (CUSTOM AuthorizationPolicy)
                                        │  does the Keycloak OIDC redirect/callback
                                        ▼
                              Langflow backend (stock image)
                              KeycloakAuthService:
                                • validates forwarded token
                                  - signature via OIDC_JWKS_URL (internal)
                                  - issuer via OIDC_ISSUER     (external)
                                • JIT-provisions the user (sso_user_profile table)
```

The interactive login is done by **oauth2-proxy at the gateway** (already wired in
this chart's `authpolicy.yaml`). Langflow does **not** run a login-redirect flow;
it only consumes the token oauth2-proxy forwards.

---

## 3. Prerequisites

1. **oauth2-proxy must forward the token to the upstream.** In your platform
   oauth2-proxy config, enable one of:
   - `--pass-authorization-header=true` (sets `Authorization: Bearer <id_token>`), or
   - `--set-authorization-header=true`, or
   - `--pass-access-token=true` (sets `X-Forwarded-Access-Token`).
   The plugin reads them in this order: `Authorization: Bearer` →
   `X-Forwarded-Access-Token` → `X-Auth-Request-Access-Token` → `X-Id-Token` →
   cookies. If none carry a Keycloak JWT, SSO users won't be recognized.

2. **The `langflow-auth` Secret** must exist (unchanged from before):
   ```bash
   kubectl create secret generic langflow-auth -n <namespace> \
     --from-literal=superuser-password='<admin-pw>' \
     --from-literal=secret-key='<stable-fernet-key>' \
     --from-literal=nvidia-api-key='<key-or-empty>'
   ```
   `secret-key` MUST stay stable across upgrades or stored credentials become
   undecryptable.

3. **Network:** the backend pod must reach `OIDC_JWKS_URL`
   (`http://keycloak.keycloak.svc.cluster.local/...`) in-cluster. The external
   `OIDC_ISSUER` is only used for the `iss` string comparison, not fetched.

---

## 4. Configure

All SSO settings are env vars in `values.yaml` under `langflow.backend.env`:

```yaml
- name: OIDC_ISSUER          # external HTTPS issuer, must equal the token's `iss`
  value: "https://keycloak.pcai-se-ai-application.hst.rdlabs.hpecorp.net/realms/UA"
- name: OIDC_JWKS_URL        # internal certs endpoint, used to fetch signing keys
  value: "http://keycloak.keycloak.svc.cluster.local/realms/UA/protocol/openid-connect/certs"
- name: OIDC_PROVIDER_NAME   # label stored in sso_user_profile.sso_provider
  value: "keycloak"
# Optional:
# - name: OIDC_AUDIENCE        # if set, `aud` is enforced
# - name: OIDC_USERNAME_CLAIM  # default: preferred_username
# - name: OIDC_EMAIL_CLAIM     # default: email
```

`OIDC_ISSUER` must match the token's `iss` claim **exactly** (trailing slash and
realm casing included). This is the #1 cause of "Invalid OIDC token".

---

## 5. Deploy

```bash
NS=<your-namespace>

# (templates/ files are not packaged; deploy from the chart directory)
helm dependency build .          # pulls the postgresql subchart if needed

# Dry-run render + server validation first
helm template langflow-ide . -n $NS \
  --set ezua.domainName=<DOMAIN_NAME> \
  | kubectl apply --dry-run=server -n $NS -f -

# Install / upgrade
helm upgrade --install langflow-ide . -n $NS --create-namespace \
  --set ezua.domainName=<DOMAIN_NAME>
```

(If you deploy through the PCAI framework-import UI instead, import the chart
`.tgz`; the `${DOMAIN_NAME}` / `${OIDC_*}` placeholders are filled by the platform.)

---

## 6. Verify

```bash
# Plugin discovered + registered (look for these log lines):
kubectl logs -n $NS statefulset/langflow-service -c langflow | \
  grep -E "KeycloakAuthService active|Installed oauth2_login|Registered service from config"

# Files landed where expected:
kubectl exec -n $NS statefulset/langflow-service -c langflow -- \
  sh -c 'cat /app/data/lfx.toml; ls -l /opt/langflow-sso/pcai_keycloak'

# Health:
kubectl get pods -n $NS -l langflow-scope=backend
```

Then browse to `https://langflow.<DOMAIN_NAME>`, authenticate at the Keycloak
prompt, and confirm a row appears:

```sql
SELECT username, sso_provider, sso_user_id, email FROM sso_user_profile;
```

Expected log on success:
`KeycloakAuthService active (provider=keycloak, issuer=..., jwks=...)`
and on first login: `JIT-provisioned SSO user '<name>' (sub=...)`.

---

## 7. Editing the auth service later

1. Edit `files/sso/pcai_keycloak/auth.py` in the chart.
2. `helm upgrade ...` — the ConfigMap is re-rendered.
3. **Restart the pod** so the new code is re-imported (plugin discovery is cached
   for the process lifetime):
   ```bash
   kubectl rollout restart statefulset/langflow-service -n $NS
   ```

---

## 8. Troubleshooting

| Symptom | Likely cause | Fix |
| --- | --- | --- |
| Falls back to local login only; SSO users rejected | oauth2-proxy not forwarding a token | Enable a `--pass-*`/`--set-*` flag (see Prereqs §3.1) |
| `Invalid OIDC token` in logs | `iss` mismatch | Make `OIDC_ISSUER` exactly equal the token `iss` |
| `OIDC not configured` | env vars empty/typo'd | Check `OIDC_ISSUER` and `OIDC_JWKS_URL` are set |
| JWKS fetch errors / timeouts | in-cluster URL unreachable or Istio mTLS | Verify `OIDC_JWKS_URL` resolves from the pod; check PeerAuthentication |
| `auth_service` not overridden (still built-in JWT) | `lfx.toml` not in `LANGFLOW_CONFIG_DIR`, or `PYTHONPATH` wrong | Confirm §6 paths; `LANGFLOW_CONFIG_DIR=/app/data`, `PYTHONPATH=/opt/langflow-sso` |
| `ModuleNotFoundError: pcai_keycloak` | package not on path | Check the `sso-plugin` mount is at `/opt/langflow-sso/pcai_keycloak` |
| `/session` returns unauthenticated for SSO | `oauth2_login` not installed | Confirm "Installed oauth2_login" log line; ensure plugin imported (restart pod) |
| Encrypted data unreadable after upgrade | `LANGFLOW_SECRET_KEY` changed | Keep `langflow-auth` Secret's `secret-key` stable |

---

## 9. What changed vs. the original chart

- `values.yaml`: backend image `axc11/langflow-sso` → `langflowai/langflow`;
  added `PYTHONPATH`, `PYTHONDONTWRITEBYTECODE`, `LANGFLOW_CONFIG_DIR`, `OIDC_*`
  env; added `sso-plugin` + `lfx-config` volumes and mounts.
- `templates/backend-statefulset.yaml`: command `python /opt/sso/run_with_sso.py …`
  → `exec python -m langflow run --backend-only`.
- `templates/sso-plugin-configmap.yaml`: **new** — inlines `files/sso/*`.
- `files/sso/**`: **new** — the plugin package, lfx.toml.

No other templates were modified.
