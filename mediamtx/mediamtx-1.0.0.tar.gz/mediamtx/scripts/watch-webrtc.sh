#!/usr/bin/env bash
# watch-webrtc.sh — watch a MediaMTX stream in real time (~200-500ms) from a
# machine that can only reach the cluster over SSH (no direct UDP route).
#
# It builds the missing UDP path by carrying WebRTC ICE/DTLS packets through
# the SSH tunnel:
#
#   browser ──UDP──▶ 127.0.0.1:8189 [laptop relay] ══TCP (ssh -L)══ [node relay] ──UDP──▶ MediaMTX :8189
#
# The node-side relay runs AS the remote command of the SSH session, so its
# lifetime is bound to the tunnel (nothing backgrounded survives session
# close on systemd nodes with KillUserProcesses=yes).
#
# Usage:
#   scripts/watch-webrtc.sh start [path]       (start watching; default path: cam)
#   scripts/watch-webrtc.sh stop
#   scripts/watch-webrtc.sh help
#
# Requires the same prerequisites as stream-laptop-camera.sh:
#   - sshpass (brew install sshpass)
#   - node key at ~/.ssh/pri_key
#   - export JUMP_PASS=...  (jump host password)

set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RELAY="$SCRIPT_DIR/webrtc-udp-relay.py"

JUMP_USER="${JUMP_USER:-onsiteteam}"
JUMP_HOST="${JUMP_HOST:-147.123.195.3}"
JUMP_PORT="${JUMP_PORT:-20022}"
JUMP_PASS="${JUMP_PASS:-d20hbWUBQ0GujYtf}"
NODE_USER="${NODE_USER:-pcadmin}"
NODE_HOST="${NODE_HOST:-10.17.31.112}"
NODE_KEY="${NODE_KEY:-$HOME/.ssh/pri_key}"
# Per-system default: "auto" resolves the CURRENT ClusterIP of mediamtx-svc
# via the node's kubectl (survives reinstalls — ClusterIPs churn). Fallback:
# the pinned LoadBalancer IP. Override via env if yours differs.
CLUSTER_IP="${CLUSTER_IP:-auto}"
WEBRTC_UDP_PORT="${WEBRTC_UDP_PORT:-8189}"

resolve_cluster_ip() {
  [ "$CLUSTER_IP" != "auto" ] && return 0
  CLUSTER_IP=$(ssh_node "sudo -n kubectl --kubeconfig /etc/kubernetes/admin.conf -n mediamtx get svc mediamtx-svc -o jsonpath='{.spec.clusterIP}'" 2>/dev/null)
  if [ -n "$CLUSTER_IP" ]; then
    echo "  resolved mediamtx-svc ClusterIP: $CLUSTER_IP (via node kubectl)"
  else
    CLUSTER_IP="10.17.32.22"
    echo "  WARNING: could not resolve ClusterIP — falling back to LB IP $CLUSTER_IP" >&2
  fi
}

STREAM_PATH="${STREAM_PATH:-cam}"
LOCAL_UDP="${LOCAL_UDP:-8189}"
LOCAL_TCP="${LOCAL_TCP:-18189}"
REMOTE_TCP="${REMOTE_TCP:-18189}"
DOMAIN="${MTX_DOMAIN:-mediamtx.dc15-0103-ai-application.pcai0103.dc15.hpecolo.net}"

SSH_PID_FILE="/tmp/mtx-watch-ssh.pid"
SSH_LOG="/tmp/mtx-watch-ssh.log"
CLIENT_PID_FILE="/tmp/mtx-watch-relay.pid"
CLIENT_LOG="/tmp/mtx-watch-relay.log"
REMOTE_RELAY="/tmp/mtx-webrtc-relay.py"

ssh_node() {
  ssh -i "$NODE_KEY" \
    -o StrictHostKeyChecking=accept-new \
    -o ProxyCommand="sshpass -e ssh -o PubkeyAuthentication=no -p ${JUMP_PORT} -o StrictHostKeyChecking=accept-new ${JUMP_USER}@${JUMP_HOST} -W %h:%p" \
    "${NODE_USER}@${NODE_HOST}" "$@"
}

precheck() {
  if [[ -z "$JUMP_PASS" ]]; then
    echo "ERROR: JUMP_PASS is not set.  export JUMP_PASS=..." >&2
    exit 1
  fi
  if [[ ! -f "$NODE_KEY" ]]; then
    echo "ERROR: node key not found at $NODE_KEY" >&2
    exit 1
  fi
  if [[ ! -f "$RELAY" ]]; then
    echo "ERROR: relay script not found at $RELAY" >&2
    exit 1
  fi
  if ! command -v python3 >/dev/null 2>&1; then
    echo "ERROR: python3 not found on this machine." >&2
    exit 1
  fi
  chmod 600 "$NODE_KEY"
  if lsof -nP -iUDP:"$LOCAL_UDP" >/dev/null 2>&1; then
    echo "ERROR: UDP port $LOCAL_UDP is already in use on this machine." >&2
    echo "  (another watch instance? or set LOCAL_UDP=<other-port>)" >&2
    exit 1
  fi
}

start_watch() {
  precheck
  resolve_cluster_ip
  export SSHPASS="$JUMP_PASS"

  echo "[1/4] copying relay to ${NODE_USER}@${NODE_HOST} ..."
  # Free the node-side port if a stale relay from a crashed/abandoned session
  # still holds it. (Do NOT pkill by name from a command that also *starts* the
  # relay — the remote shell's own cmdline matches the pattern. Here the ssh
  # command does nothing else, so a self-kill after the stale relay is dead is
  # harmless.)
  ssh_node "pkill -f 'python3 ${REMOTE_RELAY} server' 2>/dev/null; true" >/dev/null 2>&1
  ssh_node "cat > ${REMOTE_RELAY} && chmod 700 ${REMOTE_RELAY}" < "$RELAY" || {
    echo "ERROR: could not copy relay to the node." >&2
    exit 1
  }

  echo "[2/4] starting SSH tunnel with node-side relay attached ..."
  # The relay is the remote command of this session: it lives exactly as long
  # as the tunnel. Killing the ssh process tears both down cleanly.
  nohup ssh -i "$NODE_KEY" \
    -o StrictHostKeyChecking=accept-new \
    -o ExitOnForwardFailure=yes \
    -o ServerAliveInterval=15 -o ServerAliveCountMax=3 \
    -o ProxyCommand="sshpass -e ssh -o PubkeyAuthentication=no -p ${JUMP_PORT} -o StrictHostKeyChecking=accept-new ${JUMP_USER}@${JUMP_HOST} -W %h:%p" \
    -L "${LOCAL_TCP}:127.0.0.1:${REMOTE_TCP}" \
    "${NODE_USER}@${NODE_HOST}" \
    "python3 ${REMOTE_RELAY} server --tcp 127.0.0.1:${REMOTE_TCP} --udp ${CLUSTER_IP}:${WEBRTC_UDP_PORT}" \
    >"$SSH_LOG" 2>&1 &
  echo $! > "$SSH_PID_FILE"
  sleep 4
  if ! nc -z 127.0.0.1 "$LOCAL_TCP" 2>/dev/null; then
    echo "ERROR: tunnel not listening. See $SSH_LOG" >&2
    "$0" stop >/dev/null 2>&1
    exit 1
  fi
  if ! kill -0 "$(cat "$SSH_PID_FILE")" 2>/dev/null; then
    echo "ERROR: tunnel process exited (node-side relay failed?). See $SSH_LOG:" >&2
    tail -5 "$SSH_LOG" >&2
    "$0" stop >/dev/null 2>&1
    exit 1
  fi

  echo "[3/4] starting laptop-side relay (UDP ${LOCAL_UDP} <-> TCP ${LOCAL_TCP}) ..."
  # Bind on all interfaces: the browser sends STUN to this machine's LAN IP
  # (advertised as ICE candidate by MediaMTX). 127.0.0.1 candidates are
  # discarded by all major browsers as a security policy.
  # SELF-HEALING: the relay exits whenever its TCP connection blips (SSH
  # hiccup), so wrap it in a retry loop — the node relay accepts the fresh
  # connection as a new session. stop kills the LOOP pid first, then the
  # python (otherwise the loop would just respawn it).
  export RELAY LOCAL_UDP LOCAL_TCP
  nohup sh -c 'while :; do
    python3 "$RELAY" client --udp "0.0.0.0:$LOCAL_UDP" --tcp "127.0.0.1:$LOCAL_TCP" \
      || echo "[watch] relay died — restarting in 2s"
    sleep 2
  done' >"$CLIENT_LOG" 2>&1 &
  echo $! > "$CLIENT_PID_FILE"
  sleep 1
  if ! kill -0 "$(cat "$CLIENT_PID_FILE")" 2>/dev/null; then
    echo "ERROR: laptop relay failed to start. See $CLIENT_LOG" >&2
    "$0" stop >/dev/null 2>&1
    exit 1
  fi

  echo "[4/4] ready."
  echo ""
  echo "  Real-time view (~200-500 ms):"
  echo "    https://${DOMAIN}/wrtc/${STREAM_PATH}/"
  echo ""
  echo "  (trailing slash is required; keep this script running while you watch;"
  echo "   stop with: $0 stop)"
}

stop_watch() {
  export SSHPASS="${JUMP_PASS:-dummy}"
  [[ -f "$CLIENT_PID_FILE" ]] && kill "$(cat "$CLIENT_PID_FILE")" 2>/dev/null
  [[ -f "$SSH_PID_FILE" ]] && kill "$(cat "$SSH_PID_FILE")" 2>/dev/null
  pkill -f "L ${LOCAL_TCP}:127.0.0.1:${REMOTE_TCP}" 2>/dev/null
  pkill -f "webrtc-udp-relay.py client" 2>/dev/null
  rm -f "$CLIENT_PID_FILE" "$SSH_PID_FILE"
  if lsof -nP -iUDP:"$LOCAL_UDP" >/dev/null 2>&1 || nc -z 127.0.0.1 "$LOCAL_TCP" 2>/dev/null; then
    echo "Watch session may still be up (leftover processes?)."
  else
    echo "Watch session stopped."
  fi
}

print_help() {
  cat <<EOF
============================================================
 Watch a MediaMTX stream in REAL TIME (~200-500 ms)
============================================================
 Workflow:

 1) Publisher (once, in another terminal):
      scripts/stream-laptop-camera.sh start    # SSH tunnel
      ffmpeg ...                               # camera into MediaMTX

 2) Viewer (this machine):
      export JUMP_PASS=...
      scripts/watch-webrtc.sh start cam         # or: any stream path

 3) Open in a browser:
      https://${DOMAIN}/wrtc/<stream-path>/
      (trailing slash required)

 4) When done:
      scripts/watch-webrtc.sh stop

 How it works:
   WebRTC media is UDP; your machine has no UDP route to the cluster.
   This script tunnels the UDP packets through SSH (2 tiny relays),
   which the browser then uses as an ICE candidate (127.0.0.1:8189).
   The node-side relay runs inside the SSH session, so closing the
   tunnel (or this script) always cleans everything up.

 Constraints:
   - one watching tab per watch instance (per machine)
   - if the SSH session blips, the player page auto-reconnects (~2s)

 Tunables (env): STREAM_PATH, LOCAL_UDP, LOCAL_TCP, REMOTE_TCP,
   CLUSTER_IP, WEBRTC_UDP_PORT, MTX_DOMAIN, JUMP_USER/HOST/PORT,
   NODE_USER/HOST/KEY
============================================================
EOF
}

case "${1:-start}" in
  stop) stop_watch ;;
  help|--help|-h) print_help ;;
  start) STREAM_PATH="${2:-cam}" start_watch ;;
  *) STREAM_PATH="$1" start_watch ;;
esac
