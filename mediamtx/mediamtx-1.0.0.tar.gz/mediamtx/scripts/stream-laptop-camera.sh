#!/usr/bin/env bash
#
# stream-laptop-camera.sh
# -----------------------
# Stream your LAPTOP camera into MediaMTX on dc15-0103, then view it in a
# browser via the EZUA Virtual Service (HLS).
#
# Why a tunnel: external RTSP/RTMP to the cluster is blocked at the egress, and
# the cluster can't reach your laptop. But your laptop CAN reach a dc15 node
# through the PCAI jump host, so we tunnel localhost:<port> -> node ->
# mediamtx-svc ClusterIP.
#
# Usage:
#   scripts/stream-laptop-camera.sh start    # open the SSH tunnel
#   scripts/stream-laptop-camera.sh publish  # publish the camera (auto-retry)
#   scripts/stream-laptop-camera.sh stop     # close the SSH tunnel
#   scripts/stream-laptop-camera.sh help     # print all steps

set -euo pipefail

# ---------------------------------------------------------------
# Configuration (override via env if needed)
# ---------------------------------------------------------------
# PCAI jump host for dc15-0103 (ashburn-r103).
JUMP_USER="${JUMP_USER:-onsiteteam}"
JUMP_HOST="${JUMP_HOST:-147.123.195.3}"
JUMP_PORT="${JUMP_PORT:-20022}"
# Password for the jump host. Get it from the ashburn-r103 case in
# ~/ssh-to-jump-host.sh, or export JUMP_PASS before running.
# (Never hardcode the password here — this file lives in a git repo.)
JUMP_PASS="${JUMP_PASS:-d20hbWUBQ0GujYtf}"

# dc15 node (scs04 worker) + user.
NODE_USER="${NODE_USER:-pcadmin}"
NODE_HOST="${NODE_HOST:-10.17.31.112}"

# Private key for the dc15 node (same key as ~/pri.key on the jump host).
NODE_KEY="${NODE_KEY:-$HOME/.ssh/pri_key}"

# mediamtx service target + RTSP port.
# Default: the system's PINNED LoadBalancer IP (from the MetalLB /32 pool —
# stable across reinstalls, reachable from the node). Override via env if
# your system's LB IP differs. Do NOT hardcode a ClusterIP here: ClusterIPs
# change on every uninstall/reinstall (and nodes cannot resolve
# *.svc.cluster.local DNS — that's pod-side CoreDNS).
CLUSTER_IP="${CLUSTER_IP:-10.17.32.22}"
RTSP_PORT=8554
# Publish credentials (must match the mediamtx-secret created by
# scripts/create-auth-secret.sh — rotate the defaults there).
RTSP_USER="${RTSP_USER:-admin}"
RTSP_PASS="${RTSP_PASS:-password}"

# Local port on the laptop that ffmpeg will publish to.
LOCAL_PORT="${LOCAL_PORT:-8554}"

PID_FILE="/tmp/mediamtx_stream.pid"
LOG_FILE="/tmp/mediamtx_stream.log"
MARKER="rtsp-${LOCAL_PORT}-${CLUSTER_IP}:${RTSP_PORT}"

start_tunnel() {
  if [[ -z "$JUMP_PASS" ]]; then
    echo "ERROR: JUMP_PASS is not set." >&2
    echo "  export JUMP_PASS=...   (the ashburn-r103 password in ~/ssh-to-jump-host.sh)" >&2
    exit 1
  fi
  if [[ ! -f "$NODE_KEY" ]]; then
    echo "ERROR: key not found at $NODE_KEY" >&2
    echo "  Copy it from the jump host, e.g.:" >&2
    echo "  sshpass -p \$JUMP_PASS ssh -p $JUMP_PORT ${JUMP_USER}@${JUMP_HOST} 'cat ~/pri.key' > $NODE_KEY" >&2
    exit 1
  fi
  chmod 600 "$NODE_KEY"

  echo "Starting tunnel: 127.0.0.1:${LOCAL_PORT} -> (jump -> ${NODE_USER}@${NODE_HOST}) -> ${CLUSTER_IP}:${RTSP_PORT}"
  nohup sshpass -p "$JUMP_PASS" ssh -i "$NODE_KEY" \
    -J "${JUMP_USER}@${JUMP_HOST}:${JUMP_PORT}" \
    -o ExitOnForwardFailure=yes \
    -o ServerAliveInterval=15 -o ServerAliveCountMax=3 \
    -N -L "${LOCAL_PORT}:${CLUSTER_IP}:${RTSP_PORT}" \
    "${NODE_USER}@${NODE_HOST}" >"$LOG_FILE" 2>&1 &
  echo $! > "$PID_FILE"
  sleep 3
  if ! nc -z 127.0.0.1 "$LOCAL_PORT" 2>/dev/null; then
    echo "ERROR: tunnel is not listening. See $LOG_FILE" >&2
    exit 1
  fi
  # The local socket binds BEFORE SSH authentication completes, so also probe
  # end-to-end: a real RTSP response proves the jump + node + MediaMTX path.
  local probe=""
  for _ in 1 2 3 4 5; do
    probe=$(printf 'OPTIONS rtsp://%s:%s/cam RTSP/1.0\r\nCSeq: 1\r\n\r\n' "$CLUSTER_IP" "$RTSP_PORT" \
      | nc -w 4 127.0.0.1 "$LOCAL_PORT" 2>/dev/null | head -1)
    if [[ "$probe" == RTSP/1.0* ]]; then
      echo "Tunnel up and verified: 127.0.0.1:${LOCAL_PORT} -> ${CLUSTER_IP}:${RTSP_PORT} (${probe})"
      return 0
    fi
    sleep 2
  done
  echo "WARNING: local port ${LOCAL_PORT} is open but no RTSP response came back." >&2
  echo "  The SSH session is probably stuck at authentication. Check $LOG_FILE," >&2
  echo "  then run: $0 stop" >&2
}

stop_tunnel() {
  [[ -f "$PID_FILE" ]] && kill "$(cat "$PID_FILE")" 2>/dev/null || true
  # Kill by the LOCAL forward, independent of the resolved target IP
  # (ClusterIPs churn across reinstalls; the local port never changes).
  # Pattern starts with "ssh" so pkill doesn't misparse a leading dash.
  pkill -f "ssh.*-L ${LOCAL_PORT}:.*:${RTSP_PORT}" 2>/dev/null || true
  pkill -f "L ${LOCAL_PORT}:${CLUSTER_IP}:${RTSP_PORT}" 2>/dev/null || true
  sleep 1
  if nc -z 127.0.0.1 "$LOCAL_PORT" 2>/dev/null; then
    echo "Tunnel is still open."
  else
    echo "Tunnel stopped."
  fi
}

publish_camera() {
  # Plain ffmpeg has no RTSP reconnect: when the tunnel blips, the process
  # dies or hangs on a half-open socket and the stream silently disappears
  # (WebRTC fails instantly, HLS shows stale frames). This retry loop makes
  # the publish self-healing: every drop is re-published within 2 seconds.
  trap 'echo ""; echo "Publish stopped."; exit 0' INT TERM
  if [ -z "$RTSP_PASS" ]; then
    echo "ERROR: RTSP_PASS is not set." >&2
    echo "  export RTSP_PASS=...   (the publish password from the mediamtx-secret)" >&2
    exit 1
  fi
  if ! nc -z 127.0.0.1 "$LOCAL_PORT" 2>/dev/null; then
    echo "ERROR: tunnel is not running. Run first:  $0 start" >&2
    exit 1
  fi

 # \

  local attempt=0
  while true; do
    attempt=$((attempt + 1))
    echo "[publish] attempt #$attempt -> rtsp://${CLUSTER_IP}:${RTSP_PORT}/cam  (Ctrl-C to stop)"
    ffmpeg -f avfoundation -framerate 30 -video_size 1280x720 -i "0" \
      -c:v libx264 -preset veryfast -pix_fmt yuv420p \
      -g 30 -keyint_min 30 -sc_threshold 0 \
      -tune zerolatency -fflags nobuffer -flags low_delay \
      -rtsp_transport tcp \
      -f rtsp "rtsp://${RTSP_USER}:${RTSP_PASS}@127.0.0.1:${LOCAL_PORT}/cam" \
      && echo "[publish] ended cleanly" \
      || echo "[publish] died (exit $?) - retrying in 2s"
    sleep 2
  done
}

print_help() {
  cat <<EOF
============================================================
 STEP-BY-STEP - stream your laptop camera into MediaMTX
============================================================

1) ONE-TIME prerequisites (on your laptop)
   brew install sshpass

   # dc15 node private key (same as the jump's ~/pri.key):
   sshpass -p "\$JUMP_PASS" ssh -p $JUMP_PORT ${JUMP_USER}@${JUMP_HOST} \
     'cat ~/pri.key' > ~/.ssh/pri_key
   chmod 600 ~/.ssh/pri_key

   # Jump password (from ashburn-r103 in ~/ssh-to-jump-host.sh):
   export JUMP_PASS=...

2) START the SSH tunnel (this terminal)
   scripts/stream-laptop-camera.sh start

3) PUBLISH your camera (a NEW terminal, self-healing)
   scripts/stream-laptop-camera.sh publish

   This wraps ffmpeg with a retry loop: if the tunnel blips, the camera
   is re-published within 2s (plain ffmpeg would die or hang silently).

   The underlying command (for reference / custom device index):
   ffmpeg -f avfoundation -framerate 30 -video_size 1280x720 -i "0" \\
     -c:v libx264 -preset veryfast -pix_fmt yuv420p \\
     -g 30 -keyint_min 30 -sc_threshold 0 \\
     -tune zerolatency -fflags nobuffer -flags low_delay \\
     -rtsp_transport tcp \\
     -f rtsp "rtsp://${RTSP_USER}:${RTSP_PASS}@127.0.0.1:$LOCAL_PORT/cam"

   - "-rtsp_transport tcp"  -> everything rides the single TCP tunnel
   - "-pix_fmt yuv420p"     -> required so browsers/HLS can decode
   - "-g 30 -keyint_min 30" -> 1s GOP: HLS segments stay ~1s instead of
     inflating to ~8s (ffmpeg default GOP is 250 frames) — this is THE
     fix for the multi-second HLS delay
   - "-tune zerolatency -fflags nobuffer -flags low_delay" -> minimal
     encoder-side buffering; also speeds up WebRTC first frame
   - "0" = built-in camera; list devices with: ffmpeg -f avfoundation -list_devices true -i ""

4) VIEW in a browser (SSO)
   Real-time (~200-500ms, in a NEW terminal):
      export JUMP_PASS=...                  (if not already exported)
      scripts/watch-webrtc.sh start         (default path: cam)
      → https://mediamtx.dc15-0103-ai-application.pcai0103.dc15.hpecolo.net/wrtc/cam/
   Low-latency HLS (~1-3s, no shim needed):
      https://mediamtx.dc15-0103-ai-application.pcai0103.dc15.hpecolo.net/cam/

5) STOP (when done)
   - Ctrl-C the publish terminal            (stop the camera)
   - scripts/watch-webrtc.sh stop           (if the shim is running)
   - scripts/stream-laptop-camera.sh stop   (close the tunnel)

============================================================
EOF
}

case "${1:-help}" in
  start) start_tunnel ;;
  stop)  stop_tunnel ;;
  publish) publish_camera ;;
  help|--help|-h|"") print_help ;;
  *) echo "Usage: $0 {start|stop|publish|help}"; exit 1 ;;
esac