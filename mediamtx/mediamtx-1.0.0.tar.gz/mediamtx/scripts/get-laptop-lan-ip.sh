#!/bin/sh
# get-laptop-lan-ip.sh — detect the LAN IP of the machine you will WATCH the
# stream from (your laptop) and print the ready-to-paste values-pc.yaml
# snippet for mediamtxConfig.webrtcAdditionalHosts.
#
# WHY: for real-time playback over the SSH shim (scripts/watch-webrtc.sh),
# MediaMTX must advertise the viewer's own LAN IP as an ICE candidate —
# browsers discard remote 127.0.0.1 candidates, so the shim must be addressed
# via a real unicast IP. The detected IP goes into values-pc.yaml on the
# cluster side:
#
#   mediamtxConfig:
#     webrtcAdditionalHosts:
#       - "<cluster-lb-ip>"       # in-network viewers
#       - "<this script's IP>"    # the viewing laptop (shim)
#
# PORTABILITY: runs with sh OR bash; purely local detection (no network calls).
#
# Usage:
#   sh get-laptop-lan-ip.sh                    # show interface + IP
#   sh get-laptop-lan-ip.sh --lb 172.18.41.1   # + paste-ready values-pc.yaml block
#   sh get-laptop-lan-ip.sh -q                 # print only the IP (scriptable)
#   sh get-laptop-lan-ip.sh -h

set -u

QUIET=0
LB_IP=""

usage() { grep '^#' "$0" | sed 's/^# \{0,1\}//'; exit 0; }

while [ $# -gt 0 ]; do
  case "$1" in
    --lb) LB_IP="$2"; shift 2 ;;
    -q) QUIET=1; shift ;;
    -h|--help) usage ;;
    *) echo "unknown option: $1 (-h for help)" >&2; exit 1 ;;
  esac
done

is_ipv4() {
  printf '%s' "$1" | awk -F. '
    BEGIN { ok = 0 }
    {
      ok = (NF == 4)
      for (i = 1; i <= 4 && ok; i++)
        if ($i !~ /^[0-9]+$/ || $i + 0 > 255) ok = 0
    }
    END { exit ok ? 0 : 1 }'
}

IFACE=""
IP=""

case "$(uname -s)" in
  Darwin)
    IFACE=$(route -n get default 2>/dev/null | awk '/interface:/{print $2}')
    if [ -n "$IFACE" ]; then IP=$(ipconfig getifaddr "$IFACE" 2>/dev/null); fi
    ;;
  Linux)
    ROUTE_OUT=$(ip route get 1.1.1.1 2>/dev/null)
    IP=$(printf '%s' "$ROUTE_OUT" | sed -n 's/.* src \([0-9.]*\).*/\1/p')
    IFACE=$(printf '%s' "$ROUTE_OUT" | sed -n 's/.* dev \([^ ]*\).*/\1/p')
    if [ -z "$IP" ]; then
      IP=$(hostname -I 2>/dev/null | awk '{print $1}')
      IFACE=${IFACE:-"(unknown)"}
    fi
    ;;
esac

[ -n "$IP" ] || { echo "ERROR: could not detect a LAN IP (no default route?). Connect to a network and retry." >&2; exit 1; }
is_ipv4 "$IP" || { echo "ERROR: detected '$IP' is not a valid IPv4 address." >&2; exit 1; }

case "$IP" in
  127.*) echo "ERROR: detected loopback address ($IP) — not usable as an ICE candidate." >&2; exit 1 ;;
esac

if [ "$QUIET" -eq 1 ]; then
  echo "$IP"
  exit 0
fi

echo "interface: $IFACE"
echo "LAN IP:    $IP"

case "$IFACE" in
  utun*|tun*|tap*|wg*)
    echo "WARNING: '$IFACE' looks like a VPN tunnel interface. Prefer the physical" >&2
    echo "  LAN interface (en0/eth0/wlan0) — verify with: ipconfig getifaddr en0 (mac)" >&2
    ;;
esac

if [ -n "$LB_IP" ]; then
  is_ipv4 "$LB_IP" || { echo "ERROR: --lb '$LB_IP' is not a valid IPv4." >&2; exit 1; }
  cat <<EOF

Paste into values-pc.yaml on the cluster side:

 mediamtxConfig:
   webrtcAdditionalHosts:
     - "${LB_IP}"        # the cluster's LoadBalancer IP (in-network viewers)
     - "${IP}"   # this machine (real-time viewing via scripts/watch-webrtc.sh)
EOF
fi

cat <<EOF

Remember: this is a DHCP address. If the laptop changes networks or the lease
renews to a different IP, update values-pc.yaml + helm upgrade (~2 min).
EOF
