#!/bin/sh
# create-ipaddresspool.sh — discover a free LAN IP on the target cluster and
# generate the MetalLB IPAddressPool + L2Advertisement for the MediaMTX
# external LoadBalancer ("mediamtx-stream", type: LoadBalancer).
#
# PORTABILITY: runs with sh OR bash (POSIX); needs only kubectl + awk + ping
# (no python3, no jq). Run it ON the target system (e.g. SSH into a node and
# use its kubeconfig, e.g. /etc/kubernetes/admin.conf) — the ping probe then
# uses the correct L2 vantage point.
#
# WHAT IT DOES:
#   1. Preflight: MetalLB installed? (CRD + controller in metallb-system)
#   2. Discover: existing pool ranges, LoadBalancer IPs already assigned
#      cluster-wide, node IPs -> candidate subnet (nodes' /24 by default)
#   3. Pick the first free candidate (not in any pool, not assigned, not a
#      node IP), verified best-effort with a TWO-PHASE ping (ARP warm-up +
#      decisive probe, 2s deadline each — a cold-ARP first ping alone made
#      live hosts like the gateway look "free"). Silent = free; ICMP-blocked
#      devices can't be detected this way — reviewed by a human.
#   4. Print the generated manifest AND the values-pc.yaml snippet to write.
#      It never edits the chart for you.
#
# Usage:
#   sh create-ipaddresspool.sh                       # discover + print
#   sh create-ipaddresspool.sh -o FILE               # also write manifest to FILE
#   sh create-ipaddresspool.sh --apply               # also kubectl apply it
#   sh create-ipaddresspool.sh --ip 10.x.y.z         # skip discovery, force IP
#   sh create-ipaddresspool.sh --cidr 10.x.y.0/24    # override candidate subnet
#   sh create-ipaddresspool.sh -h

set -u
(set -o pipefail) 2>/dev/null && set -o pipefail

OUT_FILE=""
APPLY=0
FORCE_IP=""
CIDR_OVERRIDE=""

usage() { grep '^#' "$0" | sed 's/^# \{0,1\}//'; exit 0; }

while [ $# -gt 0 ]; do
  case "$1" in
    -o) OUT_FILE="$2"; shift 2 ;;
    --apply) APPLY=1; shift ;;
    --ip) FORCE_IP="$2"; shift 2 ;;
    --cidr) CIDR_OVERRIDE="$2"; shift 2 ;;
    -h|--help) usage ;;
    *) echo "unknown option: $1 (-h for help)" >&2; exit 1 ;;
  esac
done

command -v kubectl >/dev/null 2>&1 || { echo "ERROR: kubectl not found in PATH." >&2; exit 1; }
command -v awk >/dev/null 2>&1 || { echo "ERROR: awk not found in PATH." >&2; exit 1; }
HAVE_PING=1
command -v ping >/dev/null 2>&1 || HAVE_PING=0

# ping flags differ across platforms (Linux -W is seconds, macOS -t)
# Deadline is 2s: the FIRST ping to a host also performs ARP resolution,
# which alone can eat >1s — a 1s deadline made live hosts (e.g. the
# gateway) look "free".
case "$(uname -s)" in
  Darwin) PING_CMD="ping -c1 -t2" ;;
  *)      PING_CMD="ping -c1 -W2" ;;
esac

# probe_replies <ip> -> echoes how many of 2 pings replied (0..2)
# Two-phase: the first (warm-up) ping primes ARP and is counted too, but a
# candidate is only considered ALIVE if at least one ping got a reply.
probe_replies() {
  replies=0
  $PING_CMD "$1" >/dev/null 2>&1 && replies=$((replies + 1))
  $PING_CMD "$1" >/dev/null 2>&1 && replies=$((replies + 1))
  echo "$replies"
}

echo "== [1/4] preflight: MetalLB present? =="
if ! kubectl get crd ipaddresspools.metallb.io >/dev/null 2>&1; then
  cat >&2 <<EOF
ERROR: MetalLB is not installed on this cluster (CRD ipaddresspools.metallb.io missing).
  No IPAddressPool can help until MetalLB exists. Options:
    - Install MetalLB (https://metallb.universe.tf/installation/) into metallb-system, or
    - Ask the platform team how LoadBalancer Services get IPs on this cluster.
  NOTE: if MetalLB IS installed, this error usually means the kubeconfig could
    not be read or points at another cluster — check that it is readable by
    the current user (root-owned copies in /tmp need 'sudo chmod 644').
EOF
  exit 1
fi
echo "  MetalLB CRDs present."
kubectl -n metallb-system get deploy 2>/dev/null | grep -q metallb-controller \
  || echo "  WARNING: metallb-controller not found in metallb-system (unusual — continuing)." >&2

# Guard: this script is for NEW systems. If MediaMTX LB config already exists
# here, say so LOUDLY — its values must be KEPT, not replaced (replacing a
# working pool/LB IP with a fresh suggestion breaks a running system).
EXISTING_POOL_IP=$(kubectl -n metallb-system get ipaddresspool mediamtx-pool -o jsonpath='{.spec.addresses[*]}' 2>/dev/null)
EXISTING_LB_IP=$(kubectl get svc -A -o jsonpath='{range .items[?(@.metadata.name=="mediamtx-stream")]}{.status.loadBalancer.ingress[0].ip}{end}' 2>/dev/null)
EXISTING_MODE=0
if { [ -n "$EXISTING_POOL_IP" ] || [ -n "$EXISTING_LB_IP" ]; } && [ -z "$FORCE_IP" ] && [ -z "$CIDR_OVERRIDE" ]; then
  EXISTING_MODE=1
  SELECTED_IP="${EXISTING_LB_IP:-${EXISTING_POOL_IP%% *}}"
  SELECTED_IP="${SELECTED_IP%%/*}"   # strip "/32" if we fell back to the pool CIDR
  cat >&2 <<EOF
  ============================================================
  NOTICE: THIS SYSTEM ALREADY HAS MEDIAMTX LB CONFIGURATION
    existing pool 'mediamtx-pool': ${EXISTING_POOL_IP:-<none>}
    existing 'mediamtx-stream' LB: ${EXISTING_LB_IP:-<pending/none>}
  This script is meant for NEW systems. Skipping discovery and
  candidate picking — the EXISTING configuration is printed below.
  KEEP it in values-pc.yaml; replacing it with a new IP would
  break the running setup. (Use --ip/--cidr to override this
  behavior explicitly.)

  To DELETE the existing pool (the app's LoadBalancer goes
  <pending> until a replacement pool exists — plan for the gap):
    kubectl -n metallb-system delete ipaddresspool mediamtx-pool
    kubectl -n metallb-system delete l2advertisement mediamtx-l2-adv
  ============================================================
EOF
fi

if [ "$EXISTING_MODE" -eq 1 ]; then
  echo "== [2/4] skipping discovery — this system is already configured =="
  echo "== [3/4] skipping candidate picking — reusing the existing LB IP =="
else
echo "== [2/4] discovering pools, assigned LB IPs, node subnet =="
# Feed awk tagged lines: POOL <cidr>, ASSIGNED <ip>, NODE <ip>, OVERRIDE <cidr>
POOLS=$(kubectl -n metallb-system get ipaddresspool -o jsonpath='{range .items[*]}{.metadata.name}{"\t"}{.spec.addresses[*]}{"\n"}{end}' 2>&1) \
  || { echo "ERROR: cannot read IPAddressPools: $POOLS" >&2; exit 1; }
ASSIGNED=$(kubectl get svc -A -o jsonpath='{range .items[?(@.spec.type=="LoadBalancer")]}{.status.loadBalancer.ingress[*].ip}{"\n"}{end}' 2>/dev/null)
NODES=$(kubectl get nodes -o jsonpath='{range .items[*]}{.status.addresses[?(@.type=="InternalIP")].address}{"\n"}{end}' 2>/dev/null)

if [ -z "$NODES" ] && [ -z "$CIDR_OVERRIDE" ] && [ -z "$FORCE_IP" ]; then
  echo "ERROR: no node InternalIPs found; pass --cidr explicitly." >&2
  exit 1
fi

AWK_INPUT=""
echo "$POOLS" | while IFS= read -r line; do
  [ -n "$line" ] || continue
  name=$(printf '%s' "$line" | cut -f1)
  addrs=$(printf '%s' "$line" | cut -f2-)
  for a in $addrs; do printf 'POOL\t%s\n' "$a"; done
done > /tmp/mtx_pool_input.$$
for a in $ASSIGNED; do printf 'ASSIGNED\t%s\n' "$a" >> /tmp/mtx_pool_input.$$; done
for a in $NODES; do
  case "$a" in *:*) continue ;; esac   # skip IPv6
  printf 'NODE\t%s\n' "$a" >> /tmp/mtx_pool_input.$$
done
[ -n "$CIDR_OVERRIDE" ] && printf 'OVERRIDE\t%s\n' "$CIDR_OVERRIDE" >> /tmp/mtx_pool_input.$$

AWK_OUT=$(awk '
  function ip2int(s,  n,a,i,r) {
    n = split(s, a, ".")
    if (n != 4) return -1
    r = 0
    for (i = 1; i <= 4; i++) {
      if (a[i] !~ /^[0-9]+$/ || a[i] > 255) return -1
      r = r * 256 + a[i]
    }
    return r
  }
  function int2ip(x,  a,i) {
    for (i = 3; i >= 0; i--) { a[i] = x % 256; x = int(x / 256) }
    return a[0] "." a[1] "." a[2] "." a[3]
  }
  function parse_cidr(c,  p,ip,size) {
    split(c, parts, "/")
    if (length(parts) != 2) return 0
    ip = ip2int(parts[1]); p = parts[2] + 0
    if (ip < 0 || p < 8 || p > 32) return 0
    size = 2 ^ (32 - p)
    C_START = int(ip / size) * size
    C_END   = C_START + size - 1
    C_PLEN  = p
    return 1
  }
  function in_any_pool(ip,  c) {
    for (c in POOL_START)
      if (ip >= POOL_START[c] && ip <= POOL_END[c]) return 1
    return 0
  }
  BEGIN { OCT="^[0-9]+$" }
  $1 == "POOL" {
    if (parse_cidr($2)) { POOL_START[$2] = C_START; POOL_END[$2] = C_END; POOL_PLEN[$2] = C_PLEN }
    else POOL_START[$2] = -1
    next
  }
  $1 == "ASSIGNED" { ip2int($2) >= 0 && assigned[$2] = 1; next }
  $1 == "NODE"     { ip2int($2) >= 0 && nodes[$2] = 1; first_node = first_node ? first_node : $2; next }
  $1 == "OVERRIDE" { override = $2; next }
  END {
    printf "REPORT\n"
    for (c in POOL_START) {
      if (POOL_START[c] < 0) { printf "  pool INVALID (%s)\n", c; continue }
      printf "  pool: %s/%d  (%s)\n", int2ip(POOL_START[c]), POOL_PLEN[c], c
    }
    n = 0
    for (a in assigned) { printf "  assigned LB: %s\n", a; n++ }
    if (n == 0) printf "  assigned LB: (none)\n"
    printf "  nodes: "
    for (a in nodes) printf "%s ", a
    printf "\n"

    base = override ? override : (first_node "/24")
    if (!parse_cidr(base)) { print "ERROR: invalid subnet/cidr"; exit 1 }
    printf "SUBNET %s/%d\n", int2ip(C_START), C_PLEN

    count = 0
    cap = C_END - C_START
    if (cap > 254) cap = 254
    for (i = C_START + 1; i < C_END && count < cap; i++) {
      s = int2ip(i)
      if (s in nodes) continue
      if (s in assigned) continue
      if (in_any_pool(i)) continue
      print "CAND " s
      count++
    }
  }
' /tmp/mtx_pool_input.$$)
rm -f /tmp/mtx_pool_input.$$

echo "$AWK_OUT" | grep -v '^CAND '
echo "$AWK_OUT" | grep -q "^pool INVALID" && { echo "ERROR: a pool address is not a valid CIDR (see report)." >&2; exit 1; }
echo "$AWK_OUT" | grep -q "^ERROR" && { echo "ERROR: discovery failed (see above)." >&2; exit 1; }
echo "candidates available: $(echo "$AWK_OUT" | grep -c '^CAND ')"

if [ -n "$FORCE_IP" ]; then
  case "$FORCE_IP" in
    *.*) : ;;
    *) echo "ERROR: --ip '$FORCE_IP' is not a valid IPv4." >&2; exit 1 ;;
  esac
  SELECTED_IP="$FORCE_IP"
  echo "  using forced IP: $SELECTED_IP (skipping discovery — verify it is free!)"
else
  SUBNET=$(echo "$AWK_OUT" | sed -n 's/^SUBNET //p')
  CANDIDATES=$(echo "$AWK_OUT" | sed -n 's/^CAND //p')
  [ -z "$CANDIDATES" ] && { echo "ERROR: no free candidates in $SUBNET — try --cidr with a different subnet." >&2; exit 1; }

  echo "== [3/4] picking a free candidate (two-phase ping: ARP warm-up + decisive probe) =="
  SELECTED_IP=""
  PROBED=0
  PROBE_BUDGET=25
  if [ "$HAVE_PING" -eq 1 ]; then
    for ip in $CANDIDATES; do
      PROBED=$((PROBED + 1))
      REPLIES=$(probe_replies "$ip")
      if [ "$REPLIES" -gt 0 ]; then
        echo "  $ip responds ($REPLIES/2 probes) — taken, next."
      else
        SELECTED_IP="$ip"
        echo "  $ip silent (0/2 probes) — candidate"
        break
      fi
      [ $PROBED -ge $PROBE_BUDGET ] && break
    done
  else
    for ip in $CANDIDATES; do SELECTED_IP="$ip"; break; done
  fi
  if [ -z "$SELECTED_IP" ]; then
    # NEVER recommend a candidate that responded to ping (e.g. the gateway).
    echo "ERROR: probed $PROBED candidate(s) in $SUBNET — all responded. The subnet looks occupied." >&2
    echo "  Options:" >&2
    echo "    - find a free address yourself (ping/ip neigh) and run with: --ip <verified-free>" >&2
    echo "    - or scan a different range:                                  --cidr <other-subnet>" >&2
    exit 1
  fi
  echo "  selected: $SELECTED_IP (silent to ping = likely free)"
  echo "  NOTE: ping cannot detect ICMP-blocked devices. Confirm the IP is unused on this LAN."
fi
fi

echo "== [4/4] generated manifest =="
CLUSTER=$(kubectl config current-context 2>/dev/null || echo "unknown")
if [ "$EXISTING_MODE" -eq 1 ]; then
  POOL_ADDR_LINE="  addresses: [${EXISTING_POOL_IP}]"
else
  POOL_ADDR_LINE="  addresses: [\"${SELECTED_IP}/32\"]"
fi
MANIFEST=$(cat <<EOF
# MetalLB IPAddressPool + L2Advertisement for the MediaMTX external LoadBalancer.
# Generated by scripts/create-ipaddresspool.sh on $(date -u '+%Y-%m-%d %H:%M UTC')
# on cluster: $CLUSTER
apiVersion: metallb.io/v1beta1
kind: IPAddressPool
metadata:
  name: mediamtx-pool
  namespace: metallb-system
spec:
${POOL_ADDR_LINE}
  autoAssign: true
---
apiVersion: metallb.io/v1beta1
kind: L2Advertisement
metadata:
  name: mediamtx-l2-adv
  namespace: metallb-system
spec:
  ipAddressPools: ["mediamtx-pool"]
EOF
)
echo "$MANIFEST"
echo

if [ -n "$OUT_FILE" ]; then
  echo "$MANIFEST" > "$OUT_FILE"
  echo "manifest written to: $OUT_FILE"
fi
if [ "$APPLY" -eq 1 ]; then
  printf '%s\n' "$MANIFEST" | kubectl apply -f - && echo "applied to cluster."
fi

cat <<EOF

================================================================
 WRITE THIS INTO values-pc.yaml BEFORE INSTALLING THE APP:
================================================================
 streamingService:
   loadBalancerIPs: ["${SELECTED_IP}"]        # pin the LB IP (recommended)

 mediamtxConfig:
   webrtcAdditionalHosts:
     - "${SELECTED_IP}"                       # the LB IP (in-network viewers)
     - "<viewing-laptop-LAN-IP>"              # add when you use the SSH shim
                                              # (scripts/watch-webrtc.sh)
 Then render and install:
   DOMAIN_NAME=<this-system-domain> envsubst < values-pc.yaml > /tmp/values-pc.yaml
   helm install mediamtx . -n mediamtx --create-namespace -f /tmp/values-pc.yaml

 Verify after install:
   kubectl -n mediamtx get svc mediamtx-stream   # EXTERNAL-IP must be ${SELECTED_IP}

 To delete this pool later (the app's LoadBalancer goes <pending>
 until a replacement pool exists — plan for the gap):
   kubectl -n metallb-system delete ipaddresspool mediamtx-pool
   kubectl -n metallb-system delete l2advertisement mediamtx-l2-adv
================================================================
EOF
