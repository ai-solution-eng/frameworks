#!/usr/bin/env bash
#
# Create the Kubernetes Secret holding MediaMTX publish/read credentials.
#
# The chart (templates/deployment.yaml) injects these as env vars
# (MTX_AUTHINTERNALUSERS_1_USER/PASS) so the password never appears in a
# ConfigMap.
#
# Usage:
#   scripts/create-auth-secret.sh [namespace] [secret-name]
#
# Overrides (environment variables):
#   MTX_PUBLISH_USER       publish username  (default: admin)
#   MTX_PUBLISH_PASSWORD   publish password  (prompted if not set)
set -euo pipefail

NS="${1:-mediamtx}"
SECRET_NAME="${2:-mediamtx-secret}"

USER="${MTX_PUBLISH_USER:-admin}"
if [[ -n "${MTX_PUBLISH_PASSWORD:-}" ]]; then
  PASS="${MTX_PUBLISH_PASSWORD}"
else
  read -rsp "Publish password for '$USER': " PASS; echo
  [[ -n "$PASS" ]] || { echo "password cannot be empty" >&2; exit 1; }
fi

kubectl -n "$NS" create secret generic "$SECRET_NAME" \
  --from-literal=publishUser="$USER" \
  --from-literal=publishPassword="$PASS" \
  --dry-run=client -o yaml | kubectl -n "$NS" apply -f -

echo "Secret '$SECRET_NAME' ready in namespace '$NS' (user='$USER')."