#!/usr/bin/env python3
"""UDP <-> TCP relay for carrying WebRTC ICE/DTLS media through an SSH tunnel.

Motivation: browsers send WebRTC media over UDP only, and OpenSSH can only
forward TCP. This tool bridges the two by framing UDP datagrams over a single
bidirectional TCP stream (2-byte big-endian length prefix per datagram).

Modes:
  client:  UDP listen addr  ->  TCP connect addr   (run next to the browser)
  server:  TCP listen addr  ->  UDP target addr    (run on the far end)

Each accepted TCP connection in server mode gets its own UDP socket, so one
server process can serve multiple independent client tunnels (each tunnel =
one viewing machine; one viewing tab per tunnel).

Usage:
  webrtc-udp-relay.py client --udp 127.0.0.1:8189 --tcp 127.0.0.1:18189
  webrtc-udp-relay.py server --tcp 127.0.0.1:18189 --udp <mediamtx-ClusterIP>:8189
"""

import argparse
import asyncio
import struct
import sys

MAX_DATAGRAM = 65535
HEADER = struct.Struct(">H")


def parse_addr(value):
    host, _, port = value.rpartition(":")
    if not host or not port.isdigit():
        raise argparse.ArgumentTypeError(f"invalid address: {value} (expected host:port)")
    return host, int(port)


async def handle_server_connection(tcp_reader, tcp_writer, udp_target, index):
    label = f"conn{index}"
    loop = asyncio.get_running_loop()
    closed = asyncio.Event()

    class RelayProto(asyncio.DatagramProtocol):
        def datagram_received(self, data, addr):
            try:
                tcp_writer.write(HEADER.pack(len(data)) + data)
            except Exception:
                closed.set()

    transport, _ = await loop.create_datagram_endpoint(RelayProto, remote_addr=udp_target)
    print(f"[{label}] udp socket -> {udp_target[0]}:{udp_target[1]}", file=sys.stderr)

    async def tcp_to_udp():
        try:
            while True:
                header = await tcp_reader.readexactly(2)
                (length,) = HEADER.unpack(header)
                if length == 0 or length > MAX_DATAGRAM:
                    raise ValueError(f"bad frame length {length}")
                payload = await tcp_reader.readexactly(length)
                transport.sendto(payload)
        except (asyncio.IncompleteReadError, ConnectionError, ValueError):
            pass
        finally:
            closed.set()

    tcp_task = loop.create_task(tcp_to_udp())
    print(f"[{label}] relay up", file=sys.stderr)
    await closed.wait()
    tcp_task.cancel()
    transport.close()
    tcp_writer.close()
    print(f"[{label}] closed", file=sys.stderr)


async def run_server(args):
    index = 0

    async def handle(tcp_reader, tcp_writer):
        nonlocal index
        index += 1
        await handle_server_connection(tcp_reader, tcp_writer, args.udp, index)

    server = await asyncio.start_server(handle, args.tcp[0], args.tcp[1])
    print(f"[server] tcp listening on {args.tcp[0]}:{args.tcp[1]}", file=sys.stderr)
    async with server:
        await server.serve_forever()


async def run_client(args):
    """Multi-channel client: EACH browser source address gets its own TCP
    connection (and thus its own UDP socket on the node side). Browsers send
    ICE probes from several local sockets at once; a single shared channel
    would interleave replies with no way to demux them (the demux key — the
    ICE ufrag — is inside the encrypted payload). Per-source channels give
    each candidate pair its own clean round trip."""
    loop = asyncio.get_running_loop()
    transport_holder = {}
    channels = {}      # addr -> tcp_writer (open and healthy)
    opening = set()    # addr -> channel being established
    pending = {}       # addr -> [datagrams] queued during establishment
    MAX_CHANNELS = 8

    async def open_channel(addr):
        try:
            reader, writer = await asyncio.open_connection(args.tcp[0], args.tcp[1])
            channels[addr] = writer
            print(f"[client] channel open for {addr}", file=sys.stderr)
            for pkt in pending.pop(addr, []):
                writer.write(HEADER.pack(len(pkt)) + pkt)

            async def replies_to_addr():
                try:
                    while True:
                        header = await reader.readexactly(2)
                        (length,) = HEADER.unpack(header)
                        if length == 0 or length > MAX_DATAGRAM:
                            raise ValueError(f"bad frame length {length}")
                        payload = await reader.readexactly(length)
                        transport_holder["t"].sendto(payload, addr)
                except (asyncio.IncompleteReadError, ConnectionError, ValueError):
                    pass
                finally:
                    channels.pop(addr, None)
                    writer.close()
                    print(f"[client] channel closed for {addr}", file=sys.stderr)

            loop.create_task(replies_to_addr())
        except (ConnectionError, OSError) as exc:
            print(f"[client] channel setup failed: {exc}", file=sys.stderr)
            pending.pop(addr, None)
        finally:
            opening.discard(addr)

    class ClientProto(asyncio.DatagramProtocol):
        def datagram_received(self, data, addr):
            writer = channels.get(addr)
            if writer is not None:
                try:
                    writer.write(HEADER.pack(len(data)) + data)
                except Exception:
                    pass
                return
            if addr in opening:
                pending.setdefault(addr, []).append(data)
                return
            if len(channels) + len(opening) >= MAX_CHANNELS:
                return
            opening.add(addr)
            pending.setdefault(addr, []).append(data)
            loop.create_task(open_channel(addr))

    transport, _ = await loop.create_datagram_endpoint(
        ClientProto, local_addr=(args.udp[0], args.udp[1])
    )
    transport_holder["t"] = transport
    print(f"[client] udp listening on {args.udp[0]}:{args.udp[1]}", file=sys.stderr)

    try:
        await asyncio.Event().wait()   # run until cancelled (Ctrl-C / kill)
    finally:
        for w in channels.values():
            w.close()


def main():
    parser = argparse.ArgumentParser(description="UDP<->TCP relay over SSH-friendly framing")
    sub = parser.add_subparsers(dest="mode", required=True)

    client = sub.add_parser("client", help="UDP listen -> TCP connect (near the browser)")
    client.add_argument("--udp", type=parse_addr, required=True)
    client.add_argument("--tcp", type=parse_addr, required=True)
    client.set_defaults(func=run_client)

    server = sub.add_parser("server", help="TCP listen -> UDP target (near the media server)")
    server.add_argument("--tcp", type=parse_addr, required=True)
    server.add_argument("--udp", type=parse_addr, required=True)
    server.set_defaults(func=run_server)

    args = parser.parse_args()
    try:
        asyncio.run(args.func(args))
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
