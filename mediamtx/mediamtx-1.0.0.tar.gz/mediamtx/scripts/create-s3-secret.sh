#!/usr/bin/env bash
#
# Create the Kubernetes Secret holding MinIO/S3 credentials used by the
# MediaMTX recording sidecar (rclone) to push recorded segments to MinIO.
#
# The chart (templates/deployment.yaml) injects these via secretKeyRef
# (RCLONE_CONFIG_S3_ACCESS_KEY_ID / RCLONE_CONFIG_S3_SECRET_ACCESS_KEY) so
# they never appear in a ConfigMap.
#
# Usage:
#   scripts/create-s3-secret.sh [namespace] [secret-name]
#
# Overrides (environment variables):
#   MINIO_ACCESS_KEY   MinIO access key    (prompted if not set)
#   MINIO_SECRET_KEY   MinIO secret key    (prompted if not set)
#
# The values must match a MinIO account that can write the target bucket
# (e.g. the MinIO root account from the minio chart values, or a dedicated
# policy-restricted user created via the MinIO console).
set -euo pipefail

NS="${1:-mediamtx}"
SECRET_NAME="${2:-mediamtx-s3-creds}"

if [[ -n "${MINIO_ACCESS_KEY:-}" ]]; then
  ACCESS="${MINIO_ACCESS_KEY}"
else
  read -rsp "MinIO access key: " ACCESS; echo
  [[ -n "$ACCESS" ]] || { echo "access key cannot be empty" >&2; exit 1; }
fi

if [[ -n "${MINIO_SECRET_KEY:-}" ]]; then
  SECRET="${MINIO_SECRET_KEY}"
else
  read -rsp "MinIO secret key: " SECRET; echo
  [[ -n "$SECRET" ]] || { echo "secret key cannot be empty" >&2; exit 1; }
fi

kubectl -n "$NS" create secret generic "$SECRET_NAME" \
  --from-literal=accessKey="$ACCESS" \
  --from-literal=secretKey="$SECRET" \
  --dry-run=client -o yaml | kubectl -n "$NS" apply -f -

echo "Secret '$SECRET_NAME' ready in namespace '$NS' (keys: accessKey, secretKey)."
