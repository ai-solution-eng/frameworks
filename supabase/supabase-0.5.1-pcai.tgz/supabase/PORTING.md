# Porting guide


Added virtual service for supabase

```yaml
ezua:
  virtualService:
    endpoint: "supabase.${DOMAIN_NAME}"
```

Added auth policy and virtual service for supabase.

Updated values.yaml with the following:
```yaml
environment:
  studio:
    SUPABASE_PUBLIC_URL: https://supabase.${DOMAIN_NAME}
```

Added hpe-ezua.labels to the template and updated selectorLabels with it.
[_helpers.tpl](./templates/_helpers.tpl) Line 51: `{{ include "hpe-ezua.labels" . }}`

Update values.yaml secrets section as you see fit. Default values are provided.
- 5-year JWT keys
- DB and Dashboard password

Enabled services:
- analytics
- db
- vector
- studio
- logflare
- edgeFunctions
- postgrest
- postgresMeta

