# OpenBao for HPE AI Essentials (PCAI)

Chart: `openbao` 0.1.0 · OpenBao 2.7.3 · upstream chart `openbao` 0.30.8 (vendored)

This chart imports [OpenBao](https://openbao.org), the MPL-2.0, Linux Foundation-governed fork of
HashiCorp Vault, into HPE AI Essentials as a framework tile. It gives PCAI one place to manage
workload credentials (MinIO/S3 keys for Spark and Airflow, model-registry tokens, LLM provider
keys) instead of creating Kubernetes Secrets by hand in each project namespace.

For how this chart was built from the upstream chart and how to upgrade it, see
[PORTING.md](PORTING.md).

---

## Contents

- [Architecture](#architecture)
- [What is configured automatically](#what-is-configured-automatically)
- [Prerequisites](#prerequisites)
- [Import into AI Essentials](#import-into-ai-essentials)
- [First login](#first-login)
- [Using OpenBao from a PCAI project](#using-openbao-from-a-pcai-project)
- [Values reference](#values-reference)
- [Operations](#operations)
- [Production hardening](#production-hardening)
- [Troubleshooting](#troubleshooting)
- [Licence](#licence)

---

## Architecture

```
                         ezaf-gateway (TLS, *.DOMAIN_NAME)
  browser ──platform SSO (oauth2-proxy, /ui only)──► VirtualService ──► openbao-active:8200
  bao CLI / ESO / apps ──── /v1/* (OpenBao token auth) ──┘                      │
                                                                                 │
        openbao-0 (runs self-init once) ◄── raft :8201 ──► openbao-1, openbao-2
        auto-unseal: static key in Secret "openbao-seal-key"
        audit log: stdout of each pod

  PCAI project namespace (e.g. project-fraud-detection)
    SA openbao-reader ─► SecretStore (ESO) ─► ExternalSecret ─► Secret minio-creds ─► Spark / Airflow
```

Resource names don't depend on the release name (`fullnameOverride: openbao`):

| Resource | Name |
|---|---|
| Pods | `openbao-0`, `openbao-1`, `openbao-2` |
| In-cluster API (leader) | `http://openbao-active.<namespace>.svc.cluster.local:8200` |
| Headless (Raft peers) | `openbao-internal` |
| External URL | `https://openbao.<DOMAIN_NAME>` |

## What is configured automatically

On its first start, `openbao-0` loads `files/selfinit.hcl` and initializes OpenBao
declaratively. No one handles unseal keys or a root token, and the root token is revoked when
self-init completes. `openbao-1/2` join the cluster through `retry_join` and auto-unseal with
the same static key.

| Item | Details |
|---|---|
| Admin login | userpass user `admin`, policy `aie-admin`; password in Secret `openbao-admin-password` |
| Automation admin | Kubernetes auth role `aie-admin` → SA `openbao-admin` in the OpenBao namespace |
| Secrets store | KV v2 mount `kv`; workload secrets at `kv/pcai/<namespace>/<name>` |
| Workload identity | Kubernetes auth method (TokenReview against the in-cluster API server) |
| Per-project access | Policy `pcai-namespace-read` + role `pcai-namespace`. Any namespace with SA `openbao-reader` can read **only** `kv/pcai/<its own namespace>/*`. New projects need no OpenBao change |
| Backups | Policy and role `snapshot` for the optional snapshot CronJob |
| Audit | File audit device to stdout, collected by PCAI logging |

## Prerequisites

| Requirement | Notes |
|---|---|
| HPE AI Essentials with Import Framework | Tested design against AIE 1.x import rules (manual method) |
| PCAI admin access | Import Framework, Keycloak (optional SSO redirect) |
| Default StorageClass | 3 × 10 Gi PVCs |
| Images reachable or mirrored | `quay.io/openbao/openbao:2.7.3`; optional `ghcr.io/openbao/openbao-snapshot-agent:0.4.5` |
| External Secrets Operator | Needed to consume secrets from Spark, Airflow and KServe. Import it as a separate tile (cluster-scoped CRDs) |
| Helm 3.8+ locally | To lint and package |

## Import into AI Essentials

1. **Air-gapped clusters:** mirror the images and set `openbao.server.image.registry` (for
   example `"${AIRGAP_REGISTRY}"`).
2. **Lint and package:**
   ```bash
   helm lint openbao
   helm template openbao openbao -n openbao > /tmp/render.yaml   # optional review
   helm package openbao                                          # -> openbao-0.1.0.tgz
   ```
3. **Import:** go to *Tools & Frameworks → Import Framework*.
   - Upload `openbao-0.1.0.tgz`.
   - Release name: **`openbao`**. It must equal the pod label `hpe-ezua/app`, or the tile's health shows *Unknown*.
   - Namespace: **`openbao`**.
   - Review values. `${DOMAIN_NAME}` is substituted by AIE.
4. **Optional, seamless SSO:** in Keycloak, go to *Unified Analytics realm → Clients → UA →
   Settings → Valid redirect URIs*, and add `https://openbao.<DOMAIN_NAME>/oauth2/callback`.
5. **Verify:**
   ```bash
   kubectl -n openbao get pods                        # openbao-0..2 Running/Ready
   kubectl -n openbao exec openbao-0 -- bao status    # Initialized true, Sealed false, Seal Type static
   kubectl -n openbao logs openbao-0 | grep -i initializ
   kubectl get svc -n openbao openbao-active
   ```
6. **Back up the seal key outside the cluster.** Without it the data cannot be recovered:
   ```bash
   kubectl -n openbao get secret openbao-seal-key -o yaml > openbao-seal-key.backup.yaml
   ```

## First login

Open the tile (or `https://openbao.<DOMAIN_NAME>`):

| Field | Value |
|---|---|
| Namespace | leave empty (`/ (Root)`) |
| Method | **Username** (not Token) |
| Username | `admin` |
| Password | `kubectl -n openbao get secret openbao-admin-password -o jsonpath='{.data.password}' \| base64 -d` |

**Token alternative** (one-hour admin token):
```bash
JWT=$(kubectl -n openbao create token openbao-admin)
kubectl -n openbao exec openbao-0 -- bao write -field=token auth/kubernetes/login role=aie-admin jwt="$JWT"
```

CLI from a workstation:
```bash
export BAO_ADDR=https://openbao.<DOMAIN_NAME>
bao login -method=userpass username=admin
```

## Using OpenBao from a PCAI project

The example below uses MinIO credentials for a shared project; the same pattern works for any
credential. Replace `project-fraud-detection` with the real namespace (`kubectl get ns | grep
'^project-'`). Shared projects are `project-<name>`, personal namespaces are
`project-user-<user>`.

### 1. Create a scoped MinIO identity

In the MinIO Console:
- **Policies → Create Policy:** `fraud-detection-rw` on `arn:aws:s3:::fraud-detection` and `arn:aws:s3:::fraud-detection/*`.
- **Identity → Users → Create User:**
  - **User Name** = access key
  - **Password** = secret key. Copy it before saving; MinIO doesn't show it again.
  - Assign the policy.

If your console has no Identity menu (newer Community builds), use `mc`:
```bash
mc admin policy create m fraud-detection-rw policy.json
mc admin user add m fraud-detection-svc "$(openssl rand -hex 20)"
mc admin policy attach m fraud-detection-rw --user fraud-detection-svc
```
Don't use the MinIO root credentials.

### 2. Store it in OpenBao

UI: go to **Secrets Engines → kv → Create secret**, set the path to
`pcai/project-fraud-detection/minio`, and add these keys:

| Key | Value |
|---|---|
| `access_key` | MinIO user name / access key |
| `secret_key` | MinIO password / secret key |
| `endpoint` | `http://minio.minio.svc.cluster.local:9000` (S3 API port, not the console) |

CLI:
```bash
bao kv put kv/pcai/project-fraud-detection/minio access_key=... secret_key=... endpoint=...
```

### 3. Connect the project namespace (once per namespace)

Apply this in **the namespace where the jobs run**:

```yaml
# kubectl apply -n project-fraud-detection -f openbao-link.yaml
apiVersion: v1
kind: ServiceAccount
metadata: { name: openbao-reader }          # exact name required by role pcai-namespace
---
apiVersion: external-secrets.io/v1beta1
kind: SecretStore
metadata: { name: openbao }
spec:
  provider:
    vault:                                   # ESO's Vault provider works with OpenBao
      server: http://openbao-active.openbao.svc.cluster.local:8200
      path: kv
      version: v2
      auth:
        kubernetes:
          mountPath: kubernetes
          role: pcai-namespace
          serviceAccountRef: { name: openbao-reader }
---
apiVersion: external-secrets.io/v1beta1
kind: ExternalSecret
metadata: { name: minio-creds }
spec:
  refreshInterval: 1h
  secretStoreRef: { name: openbao, kind: SecretStore }
  target: { name: minio-creds }
  data:
    - { secretKey: AWS_ACCESS_KEY_ID,     remoteRef: { key: pcai/project-fraud-detection/minio, property: access_key } }
    - { secretKey: AWS_SECRET_ACCESS_KEY, remoteRef: { key: pcai/project-fraud-detection/minio, property: secret_key } }
    - { secretKey: S3_ENDPOINT,           remoteRef: { key: pcai/project-fraud-detection/minio, property: endpoint } }
```

```bash
kubectl -n project-fraud-detection get secretstore,externalsecret   # Valid / SecretSynced
```

PCAI reassigns SparkApplications to the submitter's namespace. If your jobs end up in
`project-user-<name>`, apply step 3 there and store the secret under
`kv/pcai/project-user-<name>/...`.

### 4. Spark

```yaml
spec:
  sparkConf:
    spark.hadoop.fs.s3a.endpoint: "http://minio.minio.svc.cluster.local:9000"
    spark.hadoop.fs.s3a.path.style.access: "true"
    # Hadoop 3.3 / SDK v1. Hadoop 3.4: software.amazon.awssdk.auth.credentials.EnvironmentVariableCredentialsProvider
    spark.hadoop.fs.s3a.aws.credentials.provider: "com.amazonaws.auth.EnvironmentVariableCredentialsProvider"
  driver:   { envFrom: [ { secretRef: { name: minio-creds } } ] }
  executor: { envFrom: [ { secretRef: { name: minio-creds } } ] }
```

### 5. Airflow

- **Spark submission:** `SparkKubernetesOperator(namespace="project-fraud-detection", application_file="job.yaml")`. The DAG has no credentials.
- **Direct S3 access:** use `KubernetesPodOperator(..., env_from=[V1EnvFromSource(secret_ref=V1SecretEnvSource(name="minio-creds"))])`.
- **Read at runtime without a Kubernetes Secret:** run the pod as SA `openbao-reader` and use `hvac` with Kubernetes auth, role `pcai-namespace`.

### 6. Rotation

1. Change the key in MinIO.
2. In OpenBao, open the secret, click **Create new version** and save. The version history is kept, so you can roll back.
3. ESO updates the Kubernetes Secret within `refreshInterval`. To refresh immediately: `kubectl annotate externalsecret minio-creds force-sync=$(date +%s) --overwrite`.
4. New pods use the new key. Running pods keep the old one until they restart.

### Migrating existing Kubernetes Secrets

OpenBao doesn't read or display Kubernetes Secrets. To bring existing ones in, copy them once:
```bash
kubectl -n "$NS" get secrets -o json | jq -c '.items[] | select(.type=="Opaque")
  | {name: .metadata.name, data: (.data // {} | map_values(@base64d))}' |
while read -r s; do
  jq '.data' <<<"$s" | bao kv put "kv/pcai/$NS/$(jq -r .name <<<"$s")" -
done
```

## Values reference

| Key | Default | Description |
|---|---|---|
| `ezua.virtualService.endpoint` | `openbao.${DOMAIN_NAME}` | External hostname |
| `ezua.virtualService.istioGateway` | `istio-system/ezaf-gateway` | AIE ingress gateway |
| `ezua.authorizationPolicy.paths` | `["/ui","/ui/*","/"]` | Paths behind platform SSO. `[]` = everything, which blocks external CLI/API clients |
| `seal.static.create` | `true` | Generate the seal key Secret (Helm `lookup` keeps it on upgrade). `false` = pre-create it |
| `seal.static.secretName` | `openbao-seal-key` | Must match `openbao.server.volumes` |
| `selfInit.admin.username` | `admin` | userpass admin |
| `selfInit.admin.createPasswordSecret` | `true` | Generate `openbao-admin-password` |
| `selfInit.kvMount` / `kvPrefix` | `kv` / `pcai` | Secret path `kv/pcai/<namespace>/...` |
| `selfInit.readerServiceAccount` | `openbao-reader` | SA name each namespace creates |
| `selfInit.tokenTTL` / `tokenMaxTTL` | `1h` / `4h` | Token lifetimes |
| `openbao.fullnameOverride` | `openbao` | Fixes resource names |
| `openbao.server.ha.replicas` | `3` | Update the `retry_join` blocks if changed |
| `openbao.server.dataStorage.size` | `10Gi` | Raft volume per pod |
| `openbao.server.extraLabels` | `hpe-ezua/*` | `hpe-ezua/app` must equal the release name |
| `openbao.snapshotAgent.enabled` | `false` | Raft snapshots to MinIO/S3 |
| `openbao.serverTelemetry.serviceMonitor.enabled` | `false` | Prometheus scraping |

Self-init settings only take effect on the **first** start. After that, change OpenBao
configuration through the UI, CLI or OpenTofu.

## Operations

| Task | Command |
|---|---|
| Status | `kubectl -n openbao exec openbao-0 -- bao status` |
| Raft peers | `bao operator raft list-peers` (as admin) |
| Audit log | `kubectl -n openbao logs openbao-0 \| grep pcai/<ns>` |
| Restart safely | Delete standbys first (`openbao-2`, `openbao-1`), then `openbao-0`; each auto-unseals |
| Manual snapshot | `bao operator raft snapshot save backup.snap` |
| Restore | `bao operator raft snapshot restore backup.snap` (requires the **same seal key**) |
| Uninstall | Remove the framework. `openbao-seal-key`, `openbao-admin-password` and the PVCs remain; delete them manually only if the data is no longer needed |

## Production hardening

- **Seal:** replace `seal "static"` with `pkcs11` (HSM), `kmip` or `transit`, and run
  OpenBao seal migration. If you deploy with GitOps or `helm template`, set
  `seal.static.create: false` and pre-create the Secret, because `lookup` can't see the
  cluster there and would generate a new key on every render.
- **Recovery keys:** `bao operator rotate-keys -init -key-shares=5 -key-threshold=3 -target=recovery`.
- **Admin:** rotate the admin password after first login, or replace userpass with OIDC (Keycloak).
- **Backups:** enable `snapshotAgent` with a dedicated MinIO bucket.
- **Monitoring:** enable the ServiceMonitor; alert on `vault_core_unsealed == 0` and on Raft leadership changes.
- **Least privilege:** keep project MinIO identities bucket-scoped, one per namespace.

## Troubleshooting

| Symptom | Cause / fix |
|---|---|
| Login page asks for a token | Switch Method to **Username** |
| Tile **Open** inactive | Check `ezua.virtualService` in EzAppConfig; `kubectl logs -n ezapp-system -l control-plane=controller-manager` |
| Tile health *Unknown* | Release name ≠ `hpe-ezua/app` label; fix `openbao.server.extraLabels` and restart the pods |
| `openbao-0` not Ready, log `self-initialization failed` | The failing request is named in the log. Fix it with the CLI as admin. Self-init doesn't re-run |
| Policy `pcai-namespace-read` missing | That request is `allow_failure`. Recreate it from `files/selfinit.hcl` with the accessor from `bao auth list -format=json` |
| `openbao-1/2` not joining | Port 8201 must bypass the Istio sidecar (pod annotations); check `retry_join` errors in the logs |
| SecretStore `InvalidProviderConfig` / 403 | SA isn't named `openbao-reader`, wrong `server` URL, or the namespace is reading another namespace's path |
| `curl .../v1/sys/health` hangs from a project | NetworkPolicy or Istio policy between namespaces |
| `openbao-0` PVC lost, peers intact | Remove `extraArgs` before restarting so it re-joins instead of self-initializing a new cluster |

## Licence

The wrapper templates belong to the chart's authors. The vendored `charts/openbao` and OpenBao
itself are MPL-2.0 (see `charts/openbao/LICENSE`).
