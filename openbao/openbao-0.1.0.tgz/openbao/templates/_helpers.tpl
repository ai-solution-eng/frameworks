{{/*
Name the upstream OpenBao subchart gives its resources (mirrors
"openbao.fullname" in charts/openbao so we can address its Services).
*/}}
{{- define "openbao-pcai.openbaoFullname" -}}
{{- $sub := .Values.openbao | default dict -}}
{{- if $sub.fullnameOverride -}}
{{- $sub.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default "openbao" $sub.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Service the VirtualService routes to: the active (leader) node in HA mode.
*/}}
{{- define "openbao-pcai.targetService" -}}
{{- $fullname := include "openbao-pcai.openbaoFullname" . -}}
{{- $sub := .Values.openbao | default dict -}}
{{- $ha := dig "server" "ha" "enabled" false $sub -}}
{{- $active := dig "server" "service" "active" "enabled" true $sub -}}
{{- if and $ha $active -}}
{{- printf "%s-active" $fullname -}}
{{- else -}}
{{- $fullname -}}
{{- end -}}
{{- end -}}

{{/*
Common labels for resources created by this wrapper chart.
*/}}
{{- define "openbao-pcai.labels" -}}
app.kubernetes.io/name: openbao
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" }}
{{- end -}}
