# Declarative self-initialization for OpenBao on HPE AI Essentials.
#
# Loaded only by pod -0 on its first start (see server.extraArgs). Runs once;
# afterwards OpenBao refuses to re-run it. The root token used here is
# revoked automatically when self-init finishes, so all later access goes
# through the auth methods created below.
#
# Placeholders (__X__) are substituted by templates/selfinit-configmap.yaml.

# 1. Administrator access ------------------------------------------------------
initialize "admin" {
  request "admin_policy" {
    operation = "update"
    path      = "sys/policies/acl/aie-admin"
    data = {
      policy = <<EOP
path "*" {
  capabilities = ["create", "read", "update", "patch", "delete", "list", "scan", "sudo"]
}
EOP
    }
  }

  request "mount_userpass" {
    operation = "update"
    path      = "sys/auth/userpass"
    data = {
      type        = "userpass"
      description = "Administrator login for the OpenBao UI and CLI."
    }
  }

  request "admin_user" {
    operation = "update"
    path      = "auth/userpass/users/__ADMIN_USER__"
    data = {
      password = {
        eval_source = "file"
        eval_type   = "string"
        path        = "/openbao/admin/password"
      }
      token_policies = ["aie-admin"]
      token_ttl      = "__TOKEN_TTL__"
      token_max_ttl  = "__TOKEN_MAX_TTL__"
    }
  }
}

# 2. KV v2 for workload secrets --------------------------------------------------
initialize "kv" {
  request "mount_kv" {
    operation = "update"
    path      = "sys/mounts/__KV_MOUNT__"
    data = {
      type        = "kv"
      description = "PCAI workload secrets: __KV_MOUNT__/__KV_PREFIX__/<namespace>/<name>"
      options = {
        version = "2"
      }
    }
  }
}

# 3. Kubernetes auth (TokenReview against the local API server) ------------------
initialize "k8s" {
  request "mount_kubernetes" {
    operation = "update"
    path      = "sys/auth/kubernetes"
    data = {
      type        = "kubernetes"
      description = "Workload identity for PCAI namespaces."
    }
  }

  request "config_kubernetes" {
    operation = "update"
    path      = "auth/kubernetes/config"
    data = {
      kubernetes_host = "https://kubernetes.default.svc"
    }
  }

  # Automation identity in the OpenBao namespace (no long-lived root token).
  request "role_admin" {
    operation = "update"
    path      = "auth/kubernetes/role/aie-admin"
    data = {
      bound_service_account_names      = ["__ADMIN_SA__"]
      bound_service_account_namespaces = ["__NAMESPACE__"]
      token_policies                   = ["aie-admin"]
      token_ttl                        = "__TOKEN_TTL__"
      token_max_ttl                    = "__TOKEN_MAX_TTL__"
    }
  }

  # Identity for the optional snapshot agent CronJob.
  request "snapshot_policy" {
    operation = "update"
    path      = "sys/policies/acl/snapshot"
    data = {
      policy = <<EOP
path "sys/storage/raft/snapshot" {
  capabilities = ["read"]
}
EOP
    }
  }

  request "role_snapshot" {
    operation = "update"
    path      = "auth/kubernetes/role/snapshot"
    data = {
      bound_service_account_names      = ["__SNAPSHOT_SA__"]
      bound_service_account_namespaces = ["__NAMESPACE__"]
      token_policies                   = ["snapshot"]
      token_ttl                        = "15m"
    }
  }

  # Mount accessor, needed for the namespace-templated policy below.
  request "read_mount" {
    operation = "read"
    path      = "sys/auth/kubernetes"
  }
}

# 4. Namespace self-service for PCAI projects ------------------------------------
# Any namespace (user or shared project) that creates a ServiceAccount named
# __READER_SA__ can log in with role "pcai-namespace" and read ONLY
#   __KV_MOUNT__/__KV_PREFIX__/<its own namespace>/*
# The policy is templated on the Kubernetes auth alias metadata, so new PCAI
# projects need no OpenBao change.
initialize "pcai" {
  request "namespace_policy" {
    operation     = "update"
    path          = "sys/policies/acl/pcai-namespace-read"
    allow_failure = true
    data = {
      policy = {
        eval_source = "cel"
        eval_type   = "string"
        expression  = <<EOC
"path \"__KV_MOUNT__/data/__KV_PREFIX__/{{identity.entity.aliases." + string(responses.k8s.read_mount.data.accessor) + ".metadata.service_account_namespace}}/*\" {\n  capabilities = [\"read\"]\n}\npath \"__KV_MOUNT__/metadata/__KV_PREFIX__/{{identity.entity.aliases." + string(responses.k8s.read_mount.data.accessor) + ".metadata.service_account_namespace}}/*\" {\n  capabilities = [\"read\", \"list\"]\n}\n"
EOC
      }
    }
  }

  request "namespace_role" {
    operation = "update"
    path      = "auth/kubernetes/role/pcai-namespace"
    data = {
      bound_service_account_names      = ["__READER_SA__"]
      bound_service_account_namespaces = ["*"]
      token_policies                   = ["pcai-namespace-read"]
      token_ttl                        = "__TOKEN_TTL__"
      token_max_ttl                    = "__TOKEN_MAX_TTL__"
    }
  }
}
