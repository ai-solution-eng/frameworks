# External Secrets Operator for HPE AI Essentials (PCAI)

Chart: `external-secrets` 0.1.0 · ESO v2.15.0 (upstream chart vendored)

[External Secrets Operator](https://external-secrets.io) (ESO) copies secrets from an external
store, here the OpenBao tile, into Kubernetes Secrets in PCAI project namespaces, and keeps
them updated. Spark, Airflow and KServe then use ordinary Kubernetes Secrets, while
credentials are managed and rotated in OpenBao.

```
OpenBao  kv/pcai/<namespace>/minio
   │  ESO logs in as SA openbao-reader (role pcai-namespace)
   ▼
Secret minio-creds in <namespace>  ──envFrom──►  Spark driver/executors, Airflow tasks
```

## What this tile deploys

| Component | Pod | Purpose |
|---|---|---|
| Controller | `external-secrets-*` | Reconciles SecretStore / ExternalSecret objects |
| Webhook | `external-secrets-webhook-*` | Validates ESO objects |
| Cert controller | `external-secrets-cert-controller-*` | Issues the webhook TLS certificate (no cert-manager needed) |
| CRDs | cluster-scoped | `SecretStore`, `ExternalSecret`, `ClusterSecretStore`, `PushSecret`, generators… (`external-secrets.io/v1`) |
| RBAC aggregation | cluster-scoped | Adds ESO object permissions to the built-in `edit`, `view` and `admin` roles, so project members can use ESO in their own namespace |

ESO has no web UI, so the tile has no endpoint and its **Open** button stays inactive. That's
expected.

## Import into AI Essentials (PCAI admin)

1. **Air-gapped:** mirror `ghcr.io/external-secrets/external-secrets:v2.15.0` and set
   `external-secrets.global.repository` (one image for all three components).
2. **Lint and package:**
   ```bash
   helm lint external-secrets
   helm package external-secrets        # -> external-secrets-0.1.0.tgz
   ```
3. **Import:** go to *Tools & Frameworks → Import Framework*, upload the `.tgz`, and use
   release name **`external-secrets`** in namespace **`external-secrets`**. The pod label
   `hpe-ezua/app` must equal the release name for tile health.
4. **Verify:**
   ```bash
   kubectl -n external-secrets get pods
   # external-secrets-xxxx                   1/1 Running
   # external-secrets-cert-controller-xxxx   1/1 Running
   # external-secrets-webhook-xxxx           1/1 Running
   kubectl api-resources | grep external-secrets.io      # APIVERSION external-secrets.io/v1
   kubectl auth can-i create externalsecrets -n project-fraud-detection --as=<pcai-user>
   ```

Install ESO **once per cluster**. If another ESO already runs in the cluster (check with
`kubectl get crd | grep external-secrets`), don't import this tile; two copies would fight
over the CRDs.

## Use with the OpenBao tile

In the namespace where the jobs run (example: `project-fraud-detection`):

```yaml
# openbao-link.yaml   kubectl apply -n project-fraud-detection -f openbao-link.yaml
apiVersion: v1
kind: ServiceAccount
metadata: { name: openbao-reader }
---
apiVersion: external-secrets.io/v1
kind: SecretStore
metadata: { name: openbao }
spec:
  provider:
    vault:
      server: http://openbao-active.openbao.svc.cluster.local:8200
      path: kv
      version: v2
      auth:
        kubernetes:
          mountPath: kubernetes
          role: pcai-namespace
          serviceAccountRef: { name: openbao-reader }
---
apiVersion: external-secrets.io/v1
kind: ExternalSecret
metadata: { name: minio-creds }
spec:
  refreshInterval: 1h
  secretStoreRef: { name: openbao, kind: SecretStore }
  target: { name: minio-creds }
  data:
    - { secretKey: AWS_ACCESS_KEY_ID,     remoteRef: { key: pcai/project-fraud-detection/minio, property: access_key } }
    - { secretKey: AWS_SECRET_ACCESS_KEY, remoteRef: { key: pcai/project-fraud-detection/minio, property: secret_key } }
    - { secretKey: S3_ENDPOINT,           remoteRef: { key: pcai/project-fraud-detection/minio, property: endpoint } }
```

Expected:
```
serviceaccount/openbao-reader created
secretstore.external-secrets.io/openbao created
externalsecret.external-secrets.io/minio-creds created

$ kubectl -n project-fraud-detection get secretstore,externalsecret
secretstore.external-secrets.io/openbao        ...  Valid          True
externalsecret.external-secrets.io/minio-creds ...  SecretSynced   True
```

Use **`external-secrets.io/v1`**. ESO v2 no longer serves `v1beta1`, and manifests using it fail
with `no matches for kind "SecretStore" in version "external-secrets.io/v1beta1"`.

## Values reference

| Key | Default | Description |
|---|---|---|
| `external-secrets.fullnameOverride` | `external-secrets` | Fixed resource names |
| `external-secrets.installCRDs` | `true` | Install CRDs with the chart |
| `external-secrets.crds.unsafeServeV1Beta1` | `false` | Temporary compatibility for old v1beta1 manifests (deprecated upstream) |
| `external-secrets.global.repository` | `""` | Image mirror for all components |
| `external-secrets.rbac.aggregateTo{View,Edit,Admin}` | `true` | Project users can manage ESO objects in their namespaces |
| `external-secrets.podLabels`, `webhook.podLabels`, `certController.podLabels` | `hpe-ezua/*` | Per-component labels (`controller`, `webhook`, `cert-controller`) |
| `…podAnnotations` | `sidecar.istio.io/inject: "false"` | Keeps ESO pods out of the mesh |
| `external-secrets.serviceMonitor.enabled` | `false` | Prometheus metrics |

## Troubleshooting

| Symptom | Cause / fix |
|---|---|
| `no matches for kind ... v1beta1` | Change `apiVersion` to `external-secrets.io/v1` |
| `failed calling webhook "validate.externalsecret..."` | Webhook pod not Ready yet, or blocked by the mesh. Check the `sidecar.istio.io/inject: "false"` annotation and the webhook logs |
| `Forbidden` creating ExternalSecret as a project user | RBAC aggregation disabled; check `kubectl get clusterrole -l rbac.authorization.k8s.io/aggregate-to-edit=true \| grep external` |
| SecretStore `InvalidProviderConfig` | Wrong OpenBao URL or SA name, or OpenBao role `pcai-namespace` missing |
| ExternalSecret `SecretSyncedError` 403 | Path isn't `pcai/<this-namespace>/...`, or OpenBao policy `pcai-namespace-read` missing |
| Tile health *Unknown* | Release name isn't `external-secrets`; adjust `hpe-ezua/app` in the three `podLabels` |
| Uninstall | **Removing the tile removes the CRDs and every SecretStore/ExternalSecret in the cluster.** The synced Kubernetes Secrets stay unless `deletionPolicy` says otherwise |

## Licence

The wrapper templates belong to the chart's authors. The vendored `charts/external-secrets` is
Apache-2.0 (see `charts/external-secrets/LICENSE`).
