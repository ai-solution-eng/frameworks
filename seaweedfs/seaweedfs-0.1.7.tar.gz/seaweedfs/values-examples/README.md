# values-examples — paste-ready values documents (secret-free)

Complete, sanitized values documents for this chart: full copies of `helm/values.yaml`
with the site decisions filled in — **not** overlay snippets, because on PCAI the values
pasted into the *Helm Values* editor **replace** the chart's `values.yaml` entirely.

Nothing here is a credential. The only secret is the `<S3_SECRET_KEY>` filler; real
per-site values live in [`helm/local/`](../local/README.md) (gitignored, excluded from
packaged charts).

## Files

| File | Target |
|---|---|
| `values.hosted-trial-ingest.yaml` | Hosted trial, **ingest window**: public S3 host open, gateway HPA armed, 3 × 250Gi with `001` replication (750Gi raw, ~375Gi usable). |
| `values.hosted-trial-locked.yaml` | The same deployment after ingest: identical except `ezua.s3VirtualService.enabled: false`. |

**The two files are byte-identical except one line.** That is a rule, not a coincidence:
the flip must be a single values edit so it cannot carry an accidental revert of
`s3.auth.secretKey` or `volume.persistence.size` with it. Verify before applying:

```bash
diff helm/values-examples/values.hosted-trial-ingest.yaml \
     helm/values-examples/values.hosted-trial-locked.yaml   # one changed line, no more
```

## Using them on PCAI

1. Import the packaged chart once.
2. Open the release's **Helm Values** editor and paste the whole file.
3. Replace the `# SITE:` lines — at minimum `storageClass` and `s3.auth.secretKey`.
4. Apply. PCAI substitutes `${DOMAIN_NAME}` before rendering.

Render-check without installing:

```bash
helm template seaweedfs helm -f helm/values-examples/values.hosted-trial-ingest.yaml
helm template seaweedfs helm -f helm/values-examples/values.hosted-trial-locked.yaml
```

## Placeholder convention

Everything you must replace is in angle brackets and named for its role —
`<S3_SECRET_KEY>`. The one exception is `${DOMAIN_NAME}`, which PCAI substitutes; leave
it verbatim.

## What these are not

`helm/local/values.g2.yaml` is the SE G2 **lab** deployment (3 × 100Gi, `001`, one S3
replica). It is gitignored and never packaged, and it is not a profile to copy.
